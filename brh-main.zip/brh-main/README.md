# Visão do produto

O projeto **BRH** é uma base de dados de _gestão de recursos humanos_. Seu objetivo é permitir a gestão dos colaboradores e departamentos da empresa. Com isso, conseguiremos futuramente dimensionar melhor a força de trabalho necessária em cada projeto, pela alocação da quantidade exata de colaboradores necessários em cada um.
